$("#btn").click(function(){
	var content=$("#textDiv").val();
	if(content !=""){
		$.ajax({
			url:"refresh.php";
			method:"POST";
			data:{body,content},
			dataType:"text",
			success:function(data){
				$("#textDiv").val("");
			}
		});
		return false;
	}
})