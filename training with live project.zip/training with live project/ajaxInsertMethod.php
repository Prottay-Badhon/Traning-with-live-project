<html>

<body>
<textarea name="comment" id="textDiv"></textarea>
<button id="btn">Post</button>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="ajaxMethod.js"></script>
</body>
</html>