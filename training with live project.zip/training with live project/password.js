$("#btn").click(function(){
	var fieldtype =  $("#pwd").attr("type");
	if(fieldtype=='password'){
		
		 $("#pwd").attr("type","text");
		 $("#btn").text("hide");
	}
	if(fieldtype=='text'){
		
		 $("#pwd").attr("type","password");
		 $("#btn").text("show");
	}
		
	
})
