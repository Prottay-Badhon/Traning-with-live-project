<html>
<head>
</head>
 <body>
		<tr>password:<td></td> <td><input type="password" id="pwd"/></td></tr>
		<tr><td></td> <td><button id="btn">Show</button></td></tr>
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="password.js"></script>
 </body>
</html>