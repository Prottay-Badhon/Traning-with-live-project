<html> 
<head>
</head>
<body>
<h1 id="change">This sentence will change after click button</h1>
<button id="show">show</button>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="jqery.js"></script>
</body>
</html>